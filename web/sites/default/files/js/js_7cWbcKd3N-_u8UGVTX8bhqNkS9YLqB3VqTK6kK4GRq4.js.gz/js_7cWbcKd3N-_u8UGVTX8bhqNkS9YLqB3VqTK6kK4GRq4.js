/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.ponal_theme = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
;
